# FileManage

file manage is used to 
1) create folder in document directory or temp directory, 
2) copy file from temp to document directory, move path,
3) remove from document directory, 
4) list all file from document directory, list file using extension from document directory (ex: if you have .mp3 and .jpg and .text files in document directory and you want only .mp3 file),
5) save file
6) get file path
